import torch
from torch import nn, optim
from torchvision import datasets, transforms, models
from torchvision.transforms.autoaugment import TrivialAugmentWide

def get_data(data_dir):
    # data_dir = args.data_dir

    train_dir = data_dir + 'train'
    valid_dir = data_dir + 'valid'
    test_dir = data_dir + 'test'
    print(train_dir)

    data_transforms = transforms.Compose([transforms.Resize(255), transforms.CenterCrop(224), transforms.ToTensor(),
                                         transforms.Normalize([0.485, 0.456, 0.406],
                                                                [0.229, 0.224, 0.225])])
    train_transforms = transforms.Compose([transforms.RandomRotation(30), transforms.RandomResizedCrop(224),
                                          transforms.RandomHorizontalFlip(), transforms.ToTensor(),
                                          transforms.Normalize([0.485, 0.456, 0.406],
                                                                [0.229, 0.224, 0.225])])
    train_datasets = datasets.ImageFolder(train_dir, train_transforms)
    # train_datasets = datasets.ImageFolder(train_dir, data_transforms)
    test_datasets = datasets.ImageFolder(test_dir, data_transforms)
    valid_datasets = datasets.ImageFolder(valid_dir, data_transforms)

    trainloaders = torch.utils.data.DataLoader(train_datasets, batch_size = 64, shuffle = True)
    testloaders = torch.utils.data.DataLoader(test_datasets, batch_size = 64, shuffle = False)
    validloaders = torch.utils.data.DataLoader(valid_datasets, batch_size = 64, shuffle = False)
    
    return trainloaders, testloaders, validloaders, train_datasets.class_to_idx


def save_checkpoint(params, model):
  if hasattr(model, 'fc'):
      m = model.fc
  else:
      m = model.classifier
  
  if m.hidden_layers:
    hidden = [each.out_features for each in m.hidden_layers] 
  else:
    hidden = []
  check = {'input_size': params['fcs'][params['arch']][1],
              'output_size': 102,
              'hidden_layers': hidden,
              'state_dict': m.state_dict(),
              'params':params}
  print(params['check_name'])
  torch.save(check, params['save_dir']+'/checkpoints/' + params['check_name'] + '.pth')


import signal

from contextlib import contextmanager

import requests


DELAY = INTERVAL = 4 * 60  # interval time in seconds
MIN_DELAY = MIN_INTERVAL = 2 * 60
KEEPALIVE_URL = "https://nebula.udacity.com/api/v1/remote/keep-alive"
TOKEN_URL = "http://metadata.google.internal/computeMetadata/v1/instance/attributes/keep_alive_token"
TOKEN_HEADERS = {"Metadata-Flavor":"Google"}


def _request_handler(headers):
    def _handler(signum, frame):
        requests.request("POST", KEEPALIVE_URL, headers=headers)
    return _handler

  
@contextmanager
def active_session(delay=DELAY, interval=INTERVAL):
    """
    Example:

    from workspace_utils import active session

    with active_session():
        # do long-running work here
    """
    print(1)
    token = requests.request("GET", TOKEN_URL, headers=TOKEN_HEADERS).text
    print(1)
    headers = {'Authorization': "STAR " + token}
    delay = max(delay, MIN_DELAY)
    interval = max(interval, MIN_INTERVAL)
    original_handler = signal.getsignal(signal.SIGALRM)
    try:
        signal.signal(signal.SIGALRM, _request_handler(headers))
        signal.setitimer(signal.ITIMER_REAL, delay, interval)
        yield
    finally:
        signal.signal(signal.SIGALRM, original_handler)
        signal.setitimer(signal.ITIMER_REAL, 0)


def keep_awake(iterable, delay=DELAY, interval=INTERVAL):
    """
    Example:

    from workspace_utils import keep_awake

    for i in keep_awake(range(5)):
        # do iteration with lots of work here
    """
    with active_session(delay, interval): yield from iterable









    