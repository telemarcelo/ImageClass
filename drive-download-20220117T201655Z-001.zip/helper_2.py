import torch
from torchvision import models

def set_params(train_params): 
  if torch.cuda.is_available() and train_params['gpu']:
    device = torch.device('cuda') 
  else:
    device = torch.device('cpu')
    train_params['gpu'] = False

  train_params['device'] = device

  # train_params['check_name']
  train_params['check_name'] = ''
  for prop in ['arch', 'hidden_units','learning_rate', 'epochs', 'gpu', 'drop_p']:
    train_params['check_name'] += str(train_params.get(prop, '')) + "_"

  print(train_params['check_name'])

  train_params['report_dir'] = train_params['save_dir'] + 'reports/'
  train_params['check_dir'] = train_params['save_dir']+ 'checkpoints/'

  train_params['model_dict'] = {'resnet18': models.resnet18, 'resnet50' : models.resnet50, 'alexnet': models.alexnet, 
            'vgg16': models.vgg16, 'densenet121' : models.densenet121}

  train_params['fcs'] = {'resnet18': ['fc',512], 'resnet50' : ['fc',2048],  'alexnet': ['classifier', 9216],
        'vgg16': ['classifier', 25088], 'densenet121' : ['classifier',1024]}